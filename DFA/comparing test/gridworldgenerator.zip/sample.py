import numpy as np
from copy import deepcopy as dcp
import matplotlib.pyplot as plt

# transition probability setting P(s'|s,a)
# input:
# S: state space,
# wall_cord: boundary states,
# A: action dict,
# epsilon: 1-epsilon = transition probability for P(s+a|s,a)

# !!!the law of grid world is: P(s'|s,a) = 1-epsilon when s' = s+a, otherwise P(s'|s+a) = epsilon/3, if s' exceed
# the state space S, then P(s|s,a) += epsilon/3

def set_P(S, A, epsilon): #wall_cord,
    P = {}
    for state in S:
        s = tuple(state)
        explore = []

        for act in A.keys():
            temp = tuple(np.array(s) + np.array(A[act]))
            explore.append(temp)
        # print s, explore
        for a in A.keys():
            P[s, a] = {}
            P[s, a][s] = 0

            s_ = tuple(np.array(s) + np.array(A[a]))
            unit = epsilon / 3

            if list(s_) in S:

                P[s, a][s_] = 1 - epsilon
                for _s_ in explore:
                    if tuple(_s_) != s_:
                        if list(_s_) in S:
                            P[s, a][tuple(_s_)] = unit
                        else:
                            P[s, a][s] += unit
            else:
                P[s, a][s] = 1 - epsilon
                for _s_ in explore:
                    if _s_ != s_:
                        if list(_s_) in S:
                            P[s, a][tuple(_s_)] = unit
                        else:
                            P[s, a][s] += unit

    return dcp(P)

def set_S(l, w):
    inner = []
    for i in range(1, l):
        for j in range(1, w):
            inner.append([i, j])
    return inner

def Sigma(s, a, P, V_):
    total = 0.0

    for s_ in P[s, a].keys():
        if s_ != s:
            total += P[s, a][s_] * V_[s_]
    return total

def init_V(S, goal):
    V, V_ = {}, {}
    for state in S:
        s = tuple(state)
        if s not in V:
            V[s], V_[s] = 0.0, 0.0
        if state in goal:
            V[s], V_[s] = 1.0, 0.0
    return dcp(V), dcp(V_)

def Dict2Vec(V, S):
    v = []
    for s in S:
        v.append(V[tuple(s)])
    return np.array(v)

def SVI(S, A, P, goal, threshold, gamma): #wall_cord,

    Pi = {}
    V, V_ = init_V(S, goal)
    # print V

    V_current, V_last = Dict2Vec(V, S), Dict2Vec(V_, S)

    it = 1

    while np.inner(V_current - V_last, V_current - V_last) > threshold: # np.inner(V_current - V_last, V_current - V_last) > threshold

        for s in S:
            V_[tuple(s)] = V[tuple(s)]

        plot_heat("SVI_result" + str(it), V, 7, 9)
        # print V

        for s in S:
            if s not in goal:
                max_v, max_a = -1.0 * 99999999, None
                for a in A:
                    if (tuple(s), a) in P:
                        v = gamma * Sigma(tuple(s), a, P, V_)
                        if v > max_v:
                            max_v, max_a = v, a

                V[tuple(s)], Pi[tuple(s)] = max_v, max_a
            else:
                Pi[tuple(s)] = []

        V_current, V_last = Dict2Vec(V, S), Dict2Vec(V_, S)
        it += 1

    return dcp(Pi), dcp(V)

def GenTraj(Pi, start, A, V):
    traj = []
    current = start
    traj.append(current)
    a = Pi[tuple(current)]
    while a!= []:
        # print current, a
        current = tuple(np.array(current) + np.array(A[a]))
        traj.append(current)
        a = Pi[tuple(current)]

    return traj

def plot_heat(name, V, l, w):

    temp = np.random.random((l, w))
    for i in range(l):
        for j in range(w):
            s = tuple([i, j])
            if s in V:
                temp[s] = V[s]
            else:
                temp[s] = -1

    plt.figure()
    plt.imshow(temp, cmap='hot', interpolation='nearest')
    plt.savefig(name + ".png") # "../DFA/comparing test/"

def plot_traj(name, V, l, w, traj): #dir,
    temp = np.random.random((l, w))
    for i in range(l):
        for j in range(w):
            s = tuple([i, j])
            if s in V:
                if s in traj:
                    temp[s] = V[s]
                else:
                    temp[s] = -1
            else:
                temp[s] = -1

    plt.figure()
    plt.imshow(temp, cmap='hot', interpolation='nearest')
    plt.savefig(name + ".png")  # "../DFA/comparing test/"

if __name__ == '__main__':
    S = set_S(7, 9) # set the width and length of grid world
    # print S
    A = {"N": (-1, 0), "S": (1, 0), "W": (0, -1), "E": (0, 1)} # initialize action space
    epsilon = 0.3 # define transition probability: 1-epsilon = P(s+a|s,a)

    P = set_P(S, A, epsilon) #w
    print "Transition Probablilities:"
    for key in P:
        print key, P[key]
    print "===================================================="

    goal  = [[6, 7]] # set the end point of your trajectory
    Pi, V = SVI(S, A, P, goal, 0.01, 0.9) # generate policy based on synchronous value iteration (SVI)
    # V is the iteration value of state space for vision aid
    # print Pi[(1,1)], Pi[(1,2)], Pi[(2,2)]

    start = [1, 1] # set the start point of your trajectory
    traj = GenTraj(Pi, start, A, V) # generate trajectory

    plot_traj("traj", V, 7, 9, traj)
    print "trajectory start from", start, "to", goal, ":"
    print traj

